package pam.pages;

public class SettingsPage {

}
