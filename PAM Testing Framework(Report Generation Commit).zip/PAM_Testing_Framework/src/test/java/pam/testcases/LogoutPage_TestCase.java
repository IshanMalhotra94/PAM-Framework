package pam.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pam.base.BaseClass;
import pam.pages.Dashboard;
import pam.pages.LoginPage;
import pam.pages.LogoutPage;
import pam.utilities.TestUtil;

public class LogoutPage_TestCase extends BaseClass{
	
	LoginPage lp;
	Dashboard dashboard;
	LogoutPage logout;
	
	public LogoutPage_TestCase()
	{
		super();
	}
	
	@BeforeMethod
	public void setup()
	{
		initilise();
		lp = new LoginPage();
		logout = new LogoutPage();
		dashboard = lp.login(pro.getProperty("username"), pro.getProperty("password"));
		logout = dashboard.clickonlogout();
	}
	
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}
	
		
	@Test(priority = 1)
	public void paymentmethod_pagetitle_Test() throws Exception
	{
		String title = logout.validatelogoutpagetitle();
		AssertJUnit.assertEquals(title, "Login");
		TestUtil.Report("Logout Page", "Logout Verification");
	}
	
	@Test(priority = 2)
	public void verifyheading_Test()
	{
		AssertJUnit.assertTrue(logout.verifyheading());
	}

}
