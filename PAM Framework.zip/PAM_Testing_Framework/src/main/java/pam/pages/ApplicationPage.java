package pam.pages;

public class ApplicationPage {

}
